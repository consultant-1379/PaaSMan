# S3

## Usage
./s3.sh 

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/asr/s3