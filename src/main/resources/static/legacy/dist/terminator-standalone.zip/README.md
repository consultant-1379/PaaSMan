# Stream Terminator

   Stream Terminator is a mediation application that terminates events from the nodes and streams out to another client. This application stream out events as raw bytes to kafka brokers. The packaging of this standalone application comes through docker image and the instructions below guides you to pull these images and run them in containers.

## Pull example for Stream Terminator

```
docker pull armdocker.rnd.ericsson.se/aia/mediation/event-stream-terminator/terminator-kafka
```

## Usage

After the image is downloaded successfully, you may run the image like below. This will start the stream terminator running inside the docker container and delivers events to the kafka topic.

```
docker run -it -P --net host --expose <stream listening port no>
armdocker.rnd.ericsson.se/aia/mediation/event-stream-terminator/terminator-kafka
-streamInPort=<stream in listening port>
-topicName=<topicName>
-brokerList=<IP Address of the kafka broker1>:<kafka broker port1>,...
-noPartitions=<No Of Partitions for the topic>
-logDir=/opt/ericsson/pmstream/terminator-standalone-kafka/logs
-logLevel=[INFO|WARN|TRACE|....]
-keySerialClass=org.apache.kafka.common.serialization.ByteArraySerializer
-valueSerialClass=org.apache.kafka.common.serialization.ByteArraySerializer
```

### Arguments

It should be noted that the docker container is started using parameters to integrate with streaming clients and the Kafka brokers. The parameters below explains integration to these stream in clients and the kafka brokers.

    docker run -it -P --net host --expose <stream listening port no> - The one highlighted sets up the default networking for docker container. Basically the docker container will be contactable by the outside world. --expose <stream listening port no> - is the port on which the stream engine listens to. See the -streamInPort below for more details.
    -streamInPort - This will be the port on which the stream terminator engine listens to events coming from the node. The default port is 10101. This is a mandatory parameter. This port will be exposed by the docker container when --expose <stream listening port no> is specified.
    -topicName - Determines which Kafka topic the terminated events are sent to. This is a mandatory parameter.
    -brokerList - This is the broker URLs of the Kafka cluster. This is a mandatory parameter. The format of the value supplied should be of: KafkaBroker-IP1:port,KafkaBroker-IP2:port,..
    -noPartitions - This is the total no., of partitions on the Kafka Topic. This is a mandatory parameter. It is important to specify this accurately. The events are load balanced and sent to the appropriate partition based on the Event Headers.
    -logDir - This is the obsolute path to the logging directory. This is an optional parameter. Defaults to "/opt/ericsson/pmstream/terminator-standalone-kafka/logs/"
    -logLevel - The logging level needed. Allowed values are one of [ERROR|WARN|INFO|DEBUG|TRACE]. This is an optional parameter. Defaults to WARN if not supplied.
    -keySerialClass - The serializer to be used by the Kafka producers to send the event key to topic. This is an optional parameter. By default ByteArraySerializer is used and this is the only supported format of the events.
    -valueSerialClass - The serializer to be used by the Kafka producers to send the event to topic. This is an optional parameter. By default ByteArraySerializer is used and this is the only supported format of the events.

### Example

```
docker run -it -P --net host --expose 35456 armdocker.rnd.ericsson.se/aia/mediation/event-stream-terminator/terminator-kafka -streamInPort=35456 -topicName=ctum -brokerList=localhost:9092,localhost:9094 -noPartitions=2  -logDir=/tmp/logs -logLevel=INFO -keySerialClass=org.apache.kafka.common.serialization.ByteArraySerializer -valueSerialClass=org.apache.kafka.common.serialization.ByteArraySerializer
```
