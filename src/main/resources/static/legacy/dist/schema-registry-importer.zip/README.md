# Schema Registry Importer
A command line tool to import avro schema into Schema Registry service

## Usage
./batch-schema-importer.sh <AVRO SCHEMA DIR> <SCHEMA REGISRTY ADDRESS>

## Example
./batch-schema-importer.sh /tmp/avro-schema http://ieatrcxb3650.athtem.eei.ericsson.se:8090/
