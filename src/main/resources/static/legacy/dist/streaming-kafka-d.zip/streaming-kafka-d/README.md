# Streaming Kafka Daemon

## Usage
./streaming-kafka-d.sh

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/asr/streaming-kafka-d