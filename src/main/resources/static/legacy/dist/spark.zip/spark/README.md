# Spark
Apache Spark™ is a fast and general engine for large-scale data processing.
Run programs up to 100x faster than Hadoop MapReduce in memory, or 10x faster on disk.
Write applications quickly in Java, Scala, Python, R.

## Usage
./spark.sh <DOCKER_HOST_IP>

## Example
./spark.sh 10.32.226.236
./spark.bat 10.32.226.236

## Pull/Run Example
docker pull armdocker.rnd.ericsson.se/aia/base/sparkbase
docker pull armdocker.rnd.ericsson.se/aia/base/sparkmaster
docker pull armdocker.rnd.ericsson.se/aia/base/sparkworker
docker run --net host -p 7077:7077 -e "DOCKER_HOST_IP=10.32.226.236" armdocker.rnd.ericsson.se/aia/base/sparkmaster