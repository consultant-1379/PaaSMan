#!/bin/bash
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 DOCKER_HOST_IP" >&2
  exit 1
fi

docker pull armdocker.rnd.ericsson.se/aia/base/sparkbase
docker pull armdocker.rnd.ericsson.se/aia/base/sparkmaster
docker pull armdocker.rnd.ericsson.se/aia/base/sparkworker
docker run --net host -p 7077:7077 -e "DOCKER_HOST_IP=$1" armdocker.rnd.ericsson.se/aia/base/sparkmaster

