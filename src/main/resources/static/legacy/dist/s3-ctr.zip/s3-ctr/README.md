# S3 ctr

## Usage
./s3-ctr.sh 

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/asr/s3-ctr