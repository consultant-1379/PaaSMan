# ASR Correlations
Consist of the following correlations:
- Userplane correlation
- Rab correlation
- Call drop correlation
- Handover correlation

# Usage
docker run --net host -v /usr/java:/usr/java -v /usr/lib:/usr/lib/ -v /etc:/etc -v /home:/home --env schemaRegistry.address=http://<SCHEMA_REGISTRY_HOST>:8081 --env mainClass=com.ericsson.aia.asr.correlations.ups.UserPlaneCorrelation_MR --env masterUrl=spark://<SPARK_MASTER_HOST>:7077  --env applicationJar=/asr/uber-aia-ref-app-radio-ups-1.0.jar --env appArguments="radio radio alluxio://<ALLUXIO_HOST>:19998 <KAFKA_HOST>:9092 60 60 http://<SCHEMA_REGISTRY_HOST>:8081" armdocker.rnd.ericsson.se/aia/<CORRELATION>

# Example
docker pull armdocker.rnd.ericsson.se/aia/demo/asr.reference.app
docker run --net host -v /usr/java:/usr/java -v /usr/lib:/usr/lib/ -v /etc:/etc -v /home:/home --env schemaRegistry.address=http://localhost:8081 --env mainClass=com.ericsson.aia.asr.correlations.ups.UserPlaneCorrelation_MR --env masterUrl=spark://localhost:7077  --env applicationJar=/asr/uber-aia-ref-app-radio-ups-1.0.jar --env appArguments="radio radio alluxio://localhost:19998 localhost:9092 60 60 http://localhost:8081" armdocker.rnd.ericsson.se/aia/asr.correlation.radio_up 
 

