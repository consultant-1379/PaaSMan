#!/bin/bash
docker pull armdocker.rnd.ericsson.se/aia/base/alluxio
docker run --privileged=true -d --name alluxio -p 19998:19998 -p 19999:19999 armdocker.rnd.ericsson.se/aia/base/alluxio
