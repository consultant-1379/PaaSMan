# GMetrics

## Usage
./gmetrics.sh

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/infrastructure/gmetrics