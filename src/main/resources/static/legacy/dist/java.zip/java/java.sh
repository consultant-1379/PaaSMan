#!/bin/bash
docker pull armdocker.rnd.ericsson.se/aia/base/java
