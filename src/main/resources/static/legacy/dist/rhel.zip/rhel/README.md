# RHEL
Linux distribution developed by Red Hat

## Usage
./rhel.sh

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/base/rhel