# AIA Playbacker

The _AIA Playbacker_ is a simulator application for continuously replaying a fixed set of events with updated timestamps so as to simulate events coming from the network.

The type of events to play back, as well as the IP and port of the Stream Terminator can be specified on the command line.

Optionally, a custom BIN file with pre-recorded events can be supplied also.

## Usage

```
docker run armdocker.rnd.ericsson.se/aia/simulators/playbacker/playbacker-single-rop <CTUM|EBM|CTR> <STREAMING_HOST> [<STREAMING_PORT>] [<BIN_FILE>]
```

### Arguments:

- 1st argument: indicates the type of events to playback i.e. `CTUM`, `EBM` or `CTR`

- `STREAMING_HOST`: The ipAddress of the event_stream_termination service to use to stream the events

- `STREAMING_PORT`: the port to use when connecting to the streaming service. By default 10101 for CTR, 10201 for CTUM and 10301 for EBM

- `BIN_FILE`: the file with the list of sorted events to stream.

### Examples

- CTR: docker run armdocker.rnd.ericsson.se/aia/simulators/playbacker/playbacker-single-rop CTR 159.107.219.230
- CTUM: docker run armdocker.rnd.ericsson.se/aia/simulators/playbacker/playbacker-single-rop CTUM 159.107.219.230
- EBM: docker run armdocker.rnd.ericsson.se/aia/simulators/playbacker/playbacker-single-rop EBM 159.107.219.230

## Pull example

docker pull armdocker.rnd.ericsson.se/aia/simulators/playbacker/playbacker-single-rop
