#!/bin/bash
docker pull armdocker.rnd.ericsson.se/aia/infrastructure/mesos_collector
