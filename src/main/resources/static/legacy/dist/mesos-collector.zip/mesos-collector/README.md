# Mesos Collector

## Usage
./mesos_collector.sh

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/infrastructure/mesos_collector