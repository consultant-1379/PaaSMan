# EPS Parser

## Usage
./eps-parser.sh 

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/asr/eps-parser