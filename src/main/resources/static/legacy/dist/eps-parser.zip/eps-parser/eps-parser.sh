#!/bin/bash
docker pull armdocker.rnd.ericsson.se/aia/asr/eps-parser
