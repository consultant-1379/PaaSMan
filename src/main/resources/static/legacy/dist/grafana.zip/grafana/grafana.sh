#!/bin/bash
docker pull armdocker.rnd.ericsson.se/aia/infrastructure/gmetrics
docker run -d --name grafana -p 80:80 -p 81:81 -p 8126:8126 -p 8125:8125/udp armdocker.rnd.ericsson.se/aia/base/grafana
