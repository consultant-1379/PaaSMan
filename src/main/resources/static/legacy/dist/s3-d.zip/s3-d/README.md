# S3 daemon

## Usage
./s3-d.sh 

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/asr/s3-d